VS_SHADER_MODEL
---------------

.. versionadded:: 3.1

Specifies the shader model of a ``.hlsl`` source file. Some shader types can
only be used with recent shader models
