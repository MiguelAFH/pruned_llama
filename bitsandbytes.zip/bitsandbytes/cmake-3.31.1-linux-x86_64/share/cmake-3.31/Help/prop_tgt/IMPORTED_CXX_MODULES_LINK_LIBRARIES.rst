IMPORTED_CXX_MODULES_LINK_LIBRARIES
-----------------------------------

.. versionadded:: 3.28

List of direct dependencies to use for usage requirements for C++ modules in
the target's C++ modules.
