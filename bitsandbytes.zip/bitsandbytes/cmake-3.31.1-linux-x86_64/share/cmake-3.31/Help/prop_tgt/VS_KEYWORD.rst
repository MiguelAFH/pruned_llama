VS_KEYWORD
----------

Removed.  This once specified the Visual Studio project keyword
for the :generator:`Visual Studio 9 2008` generator, and older,
but all of those generators have been removed.

Use the :prop_tgt:`VS_GLOBAL_KEYWORD` target property to set the
keyword for remaining :ref:`Visual Studio Generators`.
