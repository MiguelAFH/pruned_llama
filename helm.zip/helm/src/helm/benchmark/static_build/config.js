window.RELEASE = "v1.0.0";
window.BENCHMARK_OUTPUT_BASE_URL =
	"https://storage.googleapis.com/crfm-helm-public/lite/benchmark_output/";
window.PROJECT_ID = "lite";
