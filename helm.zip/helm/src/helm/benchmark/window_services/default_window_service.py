from .local_window_service import LocalWindowService


class DefaultWindowService(LocalWindowService):
    # TODO: Delete this WindowService.
    pass
